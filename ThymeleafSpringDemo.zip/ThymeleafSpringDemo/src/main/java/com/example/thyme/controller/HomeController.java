package com.example.thyme.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import domain.Person;

@Controller
public class HomeController {
	
	@RequestMapping("/home")
	public String home(Model model){
		
		Person person =new Person();
		
		
		
		model.addAttribute("person", person);
		
		return "home";
	}
	

}
