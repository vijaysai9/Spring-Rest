package com.example.thyme.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import domain.Person;

@Controller
public class HomeController {
	
	@RequestMapping("/home")
	public String home(Model model){
		
		Person person =new Person();
		
		
		
		model.addAttribute("person", person);
		
		return "home";
	}
	
	
	@RequestMapping(value="/home", method=RequestMethod.POST)
	public void  homePost(@ModelAttribute("person") Person person) {
		System.out.println(person);
	}
	
	

}
